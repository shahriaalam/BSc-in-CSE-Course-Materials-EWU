package myCircleFW;

import java.awt.Color;
import java.util.Random;

public class FactoryCircle {
	Circle temp;

	public Circle getCircleForFactory(){
		temp = new Circle();
		Random colors = new Random();
		temp.diameter = 10;
		temp.color = new Color(colors.nextInt(256),colors.nextInt(256),colors.nextInt(256));
		
		return temp;
	}
	
}
