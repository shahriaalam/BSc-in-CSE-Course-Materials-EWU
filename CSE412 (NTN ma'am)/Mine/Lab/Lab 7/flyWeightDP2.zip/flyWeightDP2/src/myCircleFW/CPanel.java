package myCircleFW;

import java.awt.Graphics;
import java.util.Random;

import javax.swing.JPanel;

public class CPanel extends JPanel{
	FactoryCircle c = new FactoryCircle();

	public CPanel(Circle c) {
		super();
		setSize(700, 700);
		this.c.temp = c;
	}

	public void paint(Graphics G) {
		Random generator = new Random();
		int x = generator.nextInt(400);
		int y = generator.nextInt(400);
		G.setColor(c.temp.color);
		G.fillOval(x, y, c.temp.diameter, c.temp.diameter);
	}
	
	
}
