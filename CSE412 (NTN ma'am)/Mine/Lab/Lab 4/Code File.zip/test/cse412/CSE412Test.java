/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cse412;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class CSE412Test {
    
    public CSE412Test() {
    }

    @Test
    public void testMain() {
    }
    
    @Test
    public void findOddEventTest1() {
        int input1 = 10;
        CSE412 utest = new CSE412();
        String actualResult = utest.findOddEven((input1));
        String expectedResult = "Even";
        assertEquals(actualResult, expectedResult);
    }
    
    @Test
    public void findOddEventTest2() {
        int input1 = 5;
        CSE412 utest = new CSE412();
        String actualResult = utest.findOddEven((input1));
        String expectedResult = "Odd";
        assertEquals(actualResult, expectedResult);
    }
    
    @Test
    public void CalculateSalaryTest1() {
        int hour = 45;
        int day = 1;
        CSE412 utest = new CSE412();
        int actualResult = utest.calculateSalary(hour, day);
        int expectedResult = 45 * 150;
        assertEquals(actualResult, expectedResult);
    }
    
    @Test
    public void CalculateSalaryTest2() {
        int hour = 50;
        int day = 1;
        CSE412 utest = new CSE412();
        int actualResult = utest.calculateSalary(hour, day);
        int expectedResult = 9000;
        assertEquals(actualResult, expectedResult);
    }
    
    @Test
    public void CalculateSalaryTest3() {
        int hour = 50;
        int day = 0;
        CSE412 utest = new CSE412();
        int actualResult = utest.calculateSalary(hour, day);
        int expectedResult = 10000;
        assertEquals(actualResult, expectedResult);
    }
    
    @Test
    public void getSessionTest1() {
        String studentID = "2020-1-60-123";
        CSE412 utest = new CSE412();
        String actual = utest.getSession(studentID);
        String expected = "Spring 20";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getSessionTest2() {
        String studentID = "2020-2-60-123";
        CSE412 utest = new CSE412();
        String actual = utest.getSession(studentID);
        String expected = "Summer 20";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getSessionTest3() {
        String studentID = "2020-3-60-123";
        CSE412 utest = new CSE412();
        String actual = utest.getSession(studentID);
        String expected = "Fall 20";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getSessionTest4() {
        String studentID = "2021-1-60-123";
        CSE412 utest = new CSE412();
        String actual = utest.getSession(studentID);
        String expected = "Out of Bound";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getDepartment5() {
        String studentID = "2020-1-60-123";
        CSE412 utest = new CSE412();
        String actual = utest.getDepartment(studentID);
        String expected = "CSE";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getDepartment6() {
        String studentID = "2020-1-50-123";
        CSE412 utest = new CSE412();
        String actual = utest.getDepartment(studentID);
        String expected = "ETE";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getDepartment7() {
        String studentID = "2020-1-55-123";
        CSE412 utest = new CSE412();
        String actual = utest.getDepartment(studentID);
        String expected = "ICE";
        assertEquals(actual, expected);
    }
    
    @Test
    public void getDepartment8() {
        String studentID = "2020-1-40-123";
        CSE412 utest = new CSE412();
        String actual = utest.getDepartment(studentID);
        String expected = "Others";
        assertEquals(actual, expected);
    }
    
}
