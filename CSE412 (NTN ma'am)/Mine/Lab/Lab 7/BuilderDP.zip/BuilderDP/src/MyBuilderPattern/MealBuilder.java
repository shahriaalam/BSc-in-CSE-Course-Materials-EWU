package MyBuilderPattern;

public class MealBuilder {

	public Meal prepareVegMeal (){
		Meal meal = new Meal();
		meal.addItem(new VegBurger());
		meal.addItem(new Pran());
		return meal;
	}
	public Meal prepareNonVegMeal (){
		Meal meal = new Meal();
		meal.addItem(new ChickenBurger());
		meal.addItem(new Mojo());
		return meal;
	}
}
