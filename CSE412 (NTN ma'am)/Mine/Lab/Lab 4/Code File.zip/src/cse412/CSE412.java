package cse412;

/**
 *
 * @author user
 */
public class CSE412 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    
    public String findOddEven(int number) {
        String flag = "Odd";
        if (number % 2 == 0)flag = "Even";
        return flag;
    }
    
    public int calculateSalary(int hour, int day) {
        if (hour < 48 && day == 1) return hour * 150;
        else if (day == 0) return hour * 200;
        else return hour * 180;
    }
    
    public String getSession(String studentID) {
        if (studentID.contains("2020-1-60")) return "Spring 20";
        else if (studentID.contains("2020-2-60")) return "Summer 20";
        else if (studentID.contains("2020-3-60")) return "Fall 20";
        else return "Out of Bound";
    }
    
    public String getDepartment(String studentID) {
        if (studentID.contains("-60-")) return "CSE";
        else if (studentID.contains("-50-")) return "ETE";
        else if (studentID.contains("-55-")) return "ICE";
        else return "Others";
    }
}
