package MyBuilderPattern;

public interface Packing {
	public String pack();

}
