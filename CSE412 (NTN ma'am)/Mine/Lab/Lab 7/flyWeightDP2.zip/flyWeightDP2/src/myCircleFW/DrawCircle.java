package myCircleFW;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class DrawCircle {
	private JFrame frame;
	private int production;

	public DrawCircle(int pr) {

		this.production = pr;
		initialize();
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		FactoryCircle factory = new FactoryCircle();


		for(int i=0; i<this.production; i++) {
			CPanel panel = new CPanel(factory.getCircleForFactory());
			frame.getContentPane().add(panel);
		}
		frame.setVisible(true);
	}


	
	
}
