package myCircleFW;

import java.awt.Color;

public class Circle {
	int diameter;
	Color color;
}
