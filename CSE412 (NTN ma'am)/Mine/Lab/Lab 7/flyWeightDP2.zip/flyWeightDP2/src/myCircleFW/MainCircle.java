package myCircleFW;

public class MainCircle {
	public static void main(String[] args) {
		int production = 100;
		DrawCircle d = new DrawCircle(production);
		System.out.println("flyweight method");

	}

}
